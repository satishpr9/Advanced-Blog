from django.shortcuts import render,get_object_or_404,redirect
from .models import Post,Profile
from .forms import PostCreateForm,UserCreateForm,UserRegistrationForm,UserEditForm,ProfileEditForm
from django.urls import reverse
from django.db.models import  Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.core.paginator import Paginator, EmptyPage,PageNotAnInteger
# Create your views here.

def index(request):
    post=Post.published.all()
    query=request.GET.get('q')
    if query:
        post=Post.published.filter(
            Q(title__icontains=query )| Q(body__icontains=query) | Q(author__username=query)
        )

        paginator=Paginator(post,4)
        page=request.GET.get('page')

        try:
            post=paginator.page(page)

        except PageNotAnInteger:
            post=paginator.page(1)
        except EmptyPage:
            post=paginator.page(paginator.num_pages)        

    context={
        'post':post
    }
    return render(request,"index.html",context)

@login_required
def post_detail(request,slug):
    allpost=Post.objects.filter( slug=slug)
    # comments=Comment.objects.filter(post=post).order_by('-id')
    # is_liked=False
    # if allpost.likes.filter(id=request.user.id).exists():
    #     is_liked=True
    context={
        'allpost':allpost,
        # 'is_liked':is_liked,
        # 'comments':comments,
       
        
    }    
    return render(request,"post_detail.html",context)

@login_required
def post_update(request):
    if request.method=="POST":
        form=PostCreateForm(request.POST)
        if form.is_valid():
            post=form.save(commit=False)
            post.author=request.user
            post.save()
    else:

         form=PostCreateForm()
    context={
        'form':form
    }   
    return render(request,"post_update.html", context)


def user_login(request):
    if request.method=="POST":
        form=UserCreateForm(request.POST)
        if form.is_valid():
            username=request.POST['username']
            password=request.POST['password']
            user=authenticate(username=username, password=password)
            if user:
                if user.is_active:
                    login(request, user)
                    return HttpResponseRedirect(reverse('index'))
                else:
                    return HttpResponse("User Is not Active ")
            else:
                return HttpResponse("user is non")  
    else:
        form=UserCreateForm()
    context={
        'form':form,
    }    
    return render(request,"login.html",context)

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('login'))

@login_required
def register(request):
    if request.method=="POST":
        form =UserRegistrationForm(request.POST or None)
        if form.is_valid():
            new_user=form.save(commit=False)
            new_user.set_password(form.cleaned_data['password'])
            new_user.save()
            Profile.objects.create(user=new_user)
            return redirect("login")
    else:
        form=UserRegistrationForm()
    context={
        'form':form,
    }     
    return render(request,"registration/register.html",context)        

@login_required
def edit_profile(request):
    if request.method=="POST":
        user_form=UserEditForm(data=request.POST or None, instance=request.user)
        profile_form=ProfileEditForm(data=request.POST or None, instance=request.user.profile, files=request.FILES)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()

    else:
        user_form=UserEditForm(instance=request.user) 
        profile_form=ProfileEditForm(instance=request.user.profile)    
    context ={
        'user_form':user_form,
        'profile_form':profile_form,
    }       

    return render(request,'edit_profile.html', context)


# def like_post(request):
#     post=get_object_or_404(Post, id=request.POST.get("post_id"))
#     is_liked=False
#     if post.likes.filter(id=request.user.id).exists():
#         post.likes.remove(request.user)
#         is_liked=False
#     else:

#         post.likes.add(request.user)
#         is_liked=True
#     return HttpResponseRedirect(post.get_absolute_url())




# def post_delete(request, slug):
#     post=get_object_or_404(Post, slug=slug)
#     if request.user !=post.author:
#         raise Http404()
#     post.delete()
#     return redirect("index")